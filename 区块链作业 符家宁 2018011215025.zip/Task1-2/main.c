//  main.c
//  BlockChain
//
//  Created by panliang on 2020/12/25.
//  Copyright © 2020 panliang. All rights reserved.

#include "stdio.h"
#include "sha256.h" 
#include "block_chain.h"
#include <string.h>

int main() {
    init(); //生成创世纪块 
    char block_name[200] = "block_two";
    int i=0;
    char content =("这是创世纪块后的第%s个块",i);
    for (i = 2; i <= 10; i++) {//创建10个区块
        new_block(block_name,content);
    }
    //unsigned long max = 0xffffffffffffffff;
    //printf("%lu\n",max);
    return 0;
}
